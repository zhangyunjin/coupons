import { AppRegistry } from "react-native";
import React, { PureComponent } from "react";
import entry from "./src/entry";

AppRegistry.registerComponent("rnfirst", () => entry);
