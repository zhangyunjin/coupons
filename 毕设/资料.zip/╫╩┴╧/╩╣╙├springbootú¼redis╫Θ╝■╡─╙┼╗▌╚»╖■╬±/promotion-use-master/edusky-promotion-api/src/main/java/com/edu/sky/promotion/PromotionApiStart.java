package com.edu.sky.promotion;

public class PromotionApiStart {
    public static void main(String[] args) {

    }
}
