package com.cloudjet.coupon.mapper;

import com.cloudjet.coupon.entity.ScopeEntity;

public interface ScopeMapper {
	int add(ScopeEntity scopeEntity);
}
