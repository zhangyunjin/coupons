package com.cloudjet.coupon.mapper;

import com.cloudjet.coupon.entity.ProductLogEntity;

public interface ProductLogMapper {

	int save(ProductLogEntity productLogEntity);
	
}
