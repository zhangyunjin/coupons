package com.cloudjet.coupon.mapper;


import com.cloudjet.coupon.entity.UserEntity;

public interface UserMapper {
	
	int add(UserEntity userEntity);
	
}
