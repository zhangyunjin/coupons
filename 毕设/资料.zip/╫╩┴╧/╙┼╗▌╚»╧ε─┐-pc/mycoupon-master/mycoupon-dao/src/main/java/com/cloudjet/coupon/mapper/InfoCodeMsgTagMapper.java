package com.cloudjet.coupon.mapper;

import com.cloudjet.coupon.entity.InfoCodeMsgTagEntity;

public interface InfoCodeMsgTagMapper {

	int save(InfoCodeMsgTagEntity infoCodeMsgTagEntity);
	
}
