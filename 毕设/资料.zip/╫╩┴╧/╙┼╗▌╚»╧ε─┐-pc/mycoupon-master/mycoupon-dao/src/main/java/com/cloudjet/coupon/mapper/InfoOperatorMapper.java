package com.cloudjet.coupon.mapper;

import com.cloudjet.coupon.entity.InfoOperatorEntity;

public interface InfoOperatorMapper {

	int add(InfoOperatorEntity infoOperatorEntity);
	
}
