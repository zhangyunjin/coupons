package com.cloudjet.coupon.mapper;

import com.cloudjet.coupon.entity.UserBagLogEntity;

public interface UserBagLogMapper {
	
	int add(UserBagLogEntity userBagLogEntity);
	
}
