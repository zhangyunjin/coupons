package com.cloudjet.coupon.entity.dto;

public class TestEntity{

}
