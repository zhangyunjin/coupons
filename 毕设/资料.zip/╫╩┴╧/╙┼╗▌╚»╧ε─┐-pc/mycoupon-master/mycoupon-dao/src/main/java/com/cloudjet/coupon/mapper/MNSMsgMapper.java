package com.cloudjet.coupon.mapper;

import com.cloudjet.coupon.entity.MNSMsgEntity;

public interface MNSMsgMapper{
	
	int save(MNSMsgEntity mnsMsgEntity);
	
}
