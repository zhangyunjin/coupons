package com.cloudjet.coupon.mapper;

import com.cloudjet.coupon.entity.ProductSortLogEntity;

public interface ProductSortLogMapper {

	int save(ProductSortLogEntity productSortLogEntity);
	
}
