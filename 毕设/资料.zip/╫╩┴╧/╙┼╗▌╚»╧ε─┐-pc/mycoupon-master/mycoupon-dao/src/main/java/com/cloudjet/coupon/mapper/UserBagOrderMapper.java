package com.cloudjet.coupon.mapper;

import com.cloudjet.coupon.entity.UserBagOrderEntity;

public interface UserBagOrderMapper {
	int add(UserBagOrderEntity userBagOrderEntity);
}
