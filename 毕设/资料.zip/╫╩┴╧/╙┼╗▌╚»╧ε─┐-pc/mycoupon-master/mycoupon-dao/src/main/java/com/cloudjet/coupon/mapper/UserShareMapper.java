package com.cloudjet.coupon.mapper;

import com.cloudjet.coupon.entity.UserShareEntity;

public interface UserShareMapper {
	
	int add(UserShareEntity userShareEntity);
	
}
